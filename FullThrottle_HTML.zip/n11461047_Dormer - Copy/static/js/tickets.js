// static/js/tickets.js
document.addEventListener('DOMContentLoaded', () => {
  // PAGE GUARD: only run on pages that have the tickets root
  const root = document.getElementById('contentRoot');
  if (!root) return;

  /* ---------- Event catalog (add more as needed) ---------- */
  const EVENTS = {
    lasvegas:  { title:"Las Vegas Grand Prix", round:"Round 22", date:"November 20 - 22",
      location:"Las Vegas Strip Circuit", price:1500, available:80, image:"static/img/lasvegas5.jpg",
      back:"details.html?event=lasvegas", blurb:"" },
    motogp1:   { title:"Australia Grand Prix", round:"Round 19", date:"October 17 - 19",
      location:"Phillip Island", price:450, available:60, image:"static/img/motogp9.jpg",
      back:"details.html?event=motogp1", blurb:"" },
    supercars3:{ title:"Sandown 500", round:"Round 12", date:"November 14 - 16",
      location:"Sandown Raceway", price:220, available:20, image:"static/img/super3.jpg",
      back:"details.html?event=supercars3", blurb:"" },
    Nascar4:   { title:"Cup Series Championship", round:"Round 40", date:"November 02",
      location:"Phoenix Raceway", price:150, available:4, image:"static/img/nascar4.jpg",
      back:"details.html?event=Nascar4", blurb:"" },
  };

  const qs  = new URLSearchParams(window.location.search);
  const key = qs.get("event");
  const ev  = EVENTS[key];

  if (!ev) {
    root.innerHTML = `<h2 class="mb-3">Event not found</h2>
                      <a href="index.html" class="btn btn-secondary">Back to Home</a>`;
    return;
  }

  const currency = n => n.toLocaleString(undefined, { style: 'currency', currency: 'AUD' });
  let available  = ev.available;

  const badgeHTML = () => available > 0
    ? `<span id="statusBadge" class="badge bg-success">Open</span>`
    : `<span id="statusBadge" class="badge bg-warning text-dark">Sold Out</span>`;

  root.innerHTML = `
    <div class="row g-4 align-items-start">
      <div class="col-md-6">
        <img src="${ev.image}" alt="${ev.title}" style="width:100%;height:500px;object-fit:cover;border-radius:.5rem">
      </div>
      <div class="col-md-6">
        <h2 class="mb-1">${ev.title} ${badgeHTML()}</h2>
        <h5 class="text-muted">${ev.round}</h5>
        <p class="mb-1"><strong>Date:</strong> ${ev.date}</p>
        <p class="mb-1"><strong>Location:</strong> ${ev.location}</p>
        <p class="mb-1"><strong>Price:</strong> ${currency(ev.price)}</p>
        <p class="mb-2"><strong>Tickets Available:</strong> <span id="avail">${available}</span></p>
        ${ev.blurb ? `<p class="mt-3">${ev.blurb}</p>` : ""}

        <div class="card shadow-sm mt-4">
          <div class="card-body">
            <div class="mb-2">
              <label class="form-label fw-semibold">Account</label>
              <div class="d-flex align-items-center gap-2">
                <input type="checkbox" id="isLoggedIn" class="form-check-input">
                <label for="isLoggedIn" class="form-check-label">I am logged in</label>
              </div>
              <div class="form-text">Prototype only: check to simulate login (required to buy).</div>
            </div>

            <!-- tickets + total -->
            <div class="row g-3 mt-2">
              <div class="col-12 col-sm-6">
                <div class="form-floating">
                  <select id="qty" class="form-select" aria-label="Number of tickets">
                    <option value=""></option>
                  </select>
                  <label for="qty">Select number of tickets</label>
                </div>
                <div class="form-text">You can’t exceed availability.</div>
              </div>
              <div class="col-12 col-sm-6">
                <div class="form-floating">
                  <input id="total" type="text" class="form-control" placeholder="$0.00" value="${currency(0)}" readonly>
                  <label for="total">Order total</label>
                </div>
              </div>
            </div>

            <div id="msg" class="mt-3"></div>

            <div class="d-flex gap-2 mt-4">
              <button id="buy" class="btn btn-dark px-4" disabled>Buy Tickets</button>
              <a href="${ev.back}" class="btn btn-outline-secondary">Back</a>
            </div>
          </div>
        </div>
      </div>
    </div>`;

  // lookups
  const qty         = document.getElementById('qty');
  const total       = document.getElementById('total');
  const msg         = document.getElementById('msg');
  const buy         = document.getElementById('buy');
  const isLoggedIn  = document.getElementById('isLoggedIn');
  const avail       = document.getElementById('avail');
  const statusBadge = document.getElementById('statusBadge');

  const setStatus = () => {
    if (available > 0) {
      statusBadge.textContent = 'Open';
      statusBadge.className   = 'badge bg-success';
    } else {
      statusBadge.textContent = 'Sold Out';
      statusBadge.className   = 'badge bg-warning text-dark';
    }
  };

  const fillQty = () => {
    // keep the blank option (for form-floating)
    qty.querySelectorAll('option:not([value=""])').forEach(o => o.remove());
    const max = Math.min(10, Math.max(available, 0));
    for (let i = 1; i <= max; i++) {
      const o = document.createElement('option');
      o.value = String(i);
      o.textContent = String(i);
      qty.appendChild(o);
    }
    qty.disabled = available === 0;
  };

  const updateState = () => {
    const n = Number(qty.value || 0);
    total.value = (n ? (n * ev.price) : 0).toLocaleString(undefined, { style:'currency', currency:'AUD' });
    msg.innerHTML = '';

    if (!n || n > available || !isLoggedIn.checked || available === 0) {
      if (n > available) {
        msg.innerHTML = '<div class="alert alert-danger mt-2 mb-0">Order cannot be placed: requested tickets exceed availability.</div>';
      } else if (!isLoggedIn.checked) {
        msg.innerHTML = '<div class="alert alert-warning mt-2 mb-0">You must be logged in to buy tickets.</div>';
      }
      buy.disabled = true;
      return;
    }
    if (n === available) {
      msg.innerHTML = '<div class="alert alert-info mt-2 mb-0">This purchase will make the event <strong>Sold Out</strong>.</div>';
    }
    buy.disabled = false;
  };

  isLoggedIn.addEventListener('change', updateState);
  qty.addEventListener('change', updateState);

  buy.addEventListener('click', () => {
    const n = Number(qty.value || 0);
    if (!n || n > available) return;

    available = Math.max(0, available - n);
    avail.textContent = available;
    setStatus();
    fillQty();
    updateState();

    const oid = 'FT-' + Date.now().toString().slice(-6) + '-' + Math.floor(Math.random()*900+100);
    document.getElementById('cEvent').textContent = ev.title;
    document.getElementById('cId').textContent    = oid;
    document.getElementById('cQty').textContent   = n;
    document.getElementById('cPaid').textContent  = (n * ev.price).toLocaleString(undefined, {style:'currency', currency:'AUD'});
    document.getElementById('cBack').setAttribute('href', ev.back);

    new bootstrap.Modal('#confirmModal').show();
  });

  // init
  setStatus();
  fillQty();
  updateState();
});
