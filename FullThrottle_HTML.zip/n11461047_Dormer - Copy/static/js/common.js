// static/js/common.js
window.ft = {
  qs:  name => new URLSearchParams(window.location.search).get(name),
  cur: n => Number(n || 0).toLocaleString(undefined, { style:'currency', currency:'AUD' })
};
