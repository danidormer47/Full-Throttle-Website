// static/js/eventmaker.js
document.addEventListener('DOMContentLoaded', () => {
  // PAGE GUARD: only run on eventmaker page (needs the form)
  const form = document.getElementById('eventForm');
  if (!form) return;

  const isLoggedIn   = document.getElementById('isLoggedIn');
  const loginHint    = document.getElementById('loginHint');
  const eventType    = document.getElementById('eventType');
  const eventTitle   = document.getElementById('eventTitle');
  const venue        = document.getElementById('venue');
  const locationEl   = document.getElementById('location');
  const startDate    = document.getElementById('startDate');
  const startTime    = document.getElementById('startTime');
  const endDate      = document.getElementById('endDate');
  const endTime      = document.getElementById('endTime');
  const tickets      = document.getElementById('tickets');
  const price        = document.getElementById('price');
  const imageInput   = document.getElementById('imageInput');
  const description  = document.getElementById('description');
  const statusBadge  = document.getElementById('statusBadge');

  // preview bits (guard in case markup differs)
  const previewImg   = document.getElementById('previewImg');
  const previewTitle = document.getElementById('previewTitle');
  const previewRound = document.getElementById('previewRound');
  const previewDates = document.getElementById('previewDates');
  const previewVenue = document.getElementById('previewVenue');
  const previewTickets = document.getElementById('previewTickets');
  const previewPrice = document.getElementById('previewPrice');
  const previewDesc  = document.getElementById('previewDesc');
  const previewStatus= document.getElementById('previewStatus');

  const cTitle  = document.getElementById('cTitle');
  const cId     = document.getElementById('cId');
  const cStatus = document.getElementById('cStatus');
  const cTickets= document.getElementById('cTickets');

  const confirmModal = document.getElementById('confirmModal')
    ? new bootstrap.Modal('#confirmModal') : null;

  const currency = n => Number(n || 0).toLocaleString(undefined, { style:'currency', currency:'USD' });

  function updateLoginState() {
    if (!isLoggedIn) return;              // guard
    const enabled = isLoggedIn.checked;
    [...form.elements].forEach(el => el.disabled = !enabled);
    if (loginHint) loginHint.classList.toggle('d-none', enabled);
  }

  function calcStatus() {
    const t   = Number(tickets.value);
    const now = new Date();
    const end = endDate.value ? new Date(endDate.value + 'T' + (endTime.value || '00:00')) : null;
    if (t === 0) return { text:'Sold Out', cls:'bg-warning text-dark' };
    if (end && end < now) return { text:'Inactive', cls:'bg-secondary' };
    return { text:'Open', cls:'bg-success' };
  }

  function updatePreview() {
    if (previewTitle) previewTitle.textContent = eventTitle.value || 'Event Title';
    if (previewRound) previewRound.textContent = (eventType.value || 'Type') + ' • ' + (venue.value || 'Venue');

    const sD = startDate.value, sT = startTime.value, eD = endDate.value, eT = endTime.value;
    const dates = [];
    if (sD) dates.push(new Date(sD).toLocaleDateString());
    if (sT) dates[dates.length-1] += ' ' + sT;
    if (eD) dates.push(new Date(eD).toLocaleDateString());
    if (eT) dates[dates.length-1] += ' ' + eT;
    if (previewDates) previewDates.textContent = dates.length ? dates.join(' – ') : 'Dates';

    if (previewVenue)   previewVenue.textContent   = locationEl.value || 'Location';
    if (previewTickets) previewTickets.textContent = 'Tickets Available: ' + (tickets.value || '—');
    if (previewPrice)   previewPrice.textContent   = 'Price: ' + (price.value ? currency(price.value) : '—');
    if (previewDesc)    previewDesc.textContent    = description.value || 'Event description will appear here…';

    const st = calcStatus();
    if (statusBadge)   { statusBadge.textContent = st.text; statusBadge.className = 'badge ' + st.cls; }
    if (previewStatus) { previewStatus.textContent = st.text; previewStatus.className = 'badge ' + st.cls; }
  }

  if (imageInput && previewImg) {
    imageInput.addEventListener('change', (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => { previewImg.src = reader.result; };
      reader.readAsDataURL(file);
    });
  }

  [eventType, eventTitle, venue, locationEl, startDate, startTime, endDate, endTime, tickets, price, description]
    .filter(Boolean)
    .forEach(el => el.addEventListener('input', updatePreview));

  const resetBtn = document.getElementById('resetBtn');
  if (resetBtn && previewImg) {
    resetBtn.addEventListener('click', () => {
      form.reset();
      previewImg.src = 'static/img/lasvegas5.jpg';
      updatePreview();
    });
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    if (isLoggedIn && !isLoggedIn.checked) {
      if (loginHint) loginHint.classList.remove('d-none');
      return;
    }

    const st = calcStatus();
    const eventObj = {
      id: 'EV-' + Date.now().toString().slice(-6) + '-' + Math.floor(Math.random()*900+100),
      type: eventType.value, title: eventTitle.value, venue: venue.value,
      location: locationEl.value, startDate: startDate.value, startTime: startTime.value,
      endDate: endDate.value, endTime: endTime.value,
      tickets: Number(tickets.value), price: Number(price.value), description: description.value,
      status: st.text
    };

    try {
      const arr = JSON.parse(localStorage.getItem('ft_events') || '[]');
      arr.push(eventObj);
      localStorage.setItem('ft_events', JSON.stringify(arr));
    } catch (_) {}

    if (cTitle)  cTitle.textContent = eventObj.title;
    if (cId)     cId.textContent    = eventObj.id;
    if (cStatus) { cStatus.textContent = eventObj.status; cStatus.className = 'badge ' + st.cls; }
    if (cTickets) cTickets.textContent = eventObj.tickets;

    if (confirmModal) confirmModal.show();
  });

  // init
  updateLoginState();
  updatePreview();
  if (isLoggedIn) isLoggedIn.addEventListener('change', updateLoginState);
});
